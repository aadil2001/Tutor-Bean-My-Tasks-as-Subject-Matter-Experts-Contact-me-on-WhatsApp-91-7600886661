package com.example.alfaisaldirectory;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EmployeeAdapter extends BaseAdapter {
    private Context context;
    private JSONArray employeesArray;

    public EmployeeAdapter(Context context, JSONArray employeesArray) {
        this.context = context;
        this.employeesArray = employeesArray;
    }

    @Override
    public int getCount() {
        return employeesArray.length();
    }

    @Override
    public Object getItem(int position) {
        try {
            return employeesArray.getJSONObject(position);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.employee_item, parent, false);
        }

        TextView tvName = convertView.findViewById(R.id.username);
        TextView affliation = convertView.findViewById(R.id.Designation);
        ImageView imageView = convertView.findViewById(R.id.imageView);

        try {
            JSONObject employee = employeesArray.getJSONObject(position);
            String name = employee.getString("name");
            String designation = employee.getString("afflation");
            String email = employee.getString("email");
            String phone = employee.getString("phone");
            String gender = employee.getString("gender");

            tvName.setText(name);
            affliation.setText(designation);

            if (gender.equals("Male")) {
                imageView.setImageResource(R.drawable.man);
            } else {
                imageView.setImageResource(R.drawable.woman);
            }

            // Set click listener
            convertView.setOnClickListener(v -> {
                Intent intent = new Intent(context, FullProfileActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("designation", designation);
                intent.putExtra("email", email);
                intent.putExtra("phone", phone);
                intent.putExtra("gender", gender);
                context.startActivity(intent);
            });

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }

}
