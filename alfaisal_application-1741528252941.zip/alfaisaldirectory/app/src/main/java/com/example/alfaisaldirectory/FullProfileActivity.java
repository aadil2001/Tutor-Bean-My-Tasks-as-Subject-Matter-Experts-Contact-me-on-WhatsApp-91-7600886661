package com.example.alfaisaldirectory;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FullProfileActivity extends AppCompatActivity {
    Button btnSubmit,homeBtn,logoutButton;
    private SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_full_profile);
        String name = getIntent().getStringExtra("name");
        String designation = getIntent().getStringExtra("designation");
        String email = getIntent().getStringExtra("email");
        String phone = getIntent().getStringExtra("phone");
        String gender = getIntent().getStringExtra("gender");

        // Get references to UI elements
        TextView tvName = findViewById(R.id.username);
        TextView tvDesignation = findViewById(R.id.designation);
        TextView tvEmail = findViewById(R.id.email);
        TextView tvPhone = findViewById(R.id.phone);
        ImageView profileImage = findViewById(R.id.profile_image);

        homeBtn=findViewById(R.id.homeBtn);
        logoutButton=findViewById(R.id.logoutButton);
        sharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        // Set data in UI
        tvName.setText(name);
        tvDesignation.setText(designation);
        tvEmail.setText(email);
        tvPhone.setText(phone);

        if (gender.equals("Male")) {
            profileImage.setImageResource(R.drawable.man);
        } else {
            profileImage.setImageResource(R.drawable.woman);
        }
        homeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(FullProfileActivity.this,HomeActivity.class);
                startActivity(intent);
            }
        });
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Clear login state
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean("isLoggedIn", false);  // Set to false to indicate logout
                editor.apply();

                // Redirect to Login Activity
                Intent intent = new Intent(FullProfileActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);  // Clears activity stack
                startActivity(intent);
                finish();  // Close current activity
            }
        });
//
    }
}